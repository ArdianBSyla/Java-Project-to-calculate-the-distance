import javax.swing.*;
import java.awt.*;
/** MyWriter creates a graphics window that displays some sentences 
  * these sentences tell us how long is the distance for the given values of V, a and t  */
public class CalculationOfDistances extends JPanel
{
   private int width; // the frame's width
   private int height; // the frame's height
  
   private String sentence0 = "Distanca d per kohen t=0 eshte: "; // holds the sentence to be displayed
   private String sentence1 = "Distanca d per kohen t=1 eshte: "; 
   private String sentence2 = "Distanca d per kohen t=2 eshte: "; 
   private String sentence3 = "Distanca d per kohen t=3 eshte: "; 
   private String sentence4 = "Distanca d per kohen t=4 eshte: "; 
   private String sentence5 = "Distanca d per kohen t=5 eshte: "; 
   private String sentence6 = "Distanca d per kohen t=6 eshte: "; 
   private String sentence7 = "Distanca d per kohen t=7 eshte: "; 
   private String sentence8 = "Distanca d per kohen t=8 eshte: "; 
   private String sentence9 = "Distanca d per kohen t=9 eshte: "; 
   private String sentence10 = "Distanca d per kohen t=10 eshte: "; 
   private int xposition; // x-position of sentence
   private int yposition; // y-position of sentence
   private int increment = 20; // increment between sentences
   
   private double V; // vlera e V
   private double t; // vlera e t
   private int a; // vlera e a
   private double d; // vlera e d
   
   /** Constructor Detyra creates the Panel
     * @param w - the window's width
     * @param h - the window's height */
   public CalculationOfDistances(int w, int h)
   {
      width = w;
      height = h;
     
      xposition = width/10;  // set the sentence's position
      yposition = height/10;
      
      JFrame myframe = new JFrame();
      myframe.getContentPane().add(this);
      myframe.setSize(w, h);
      myframe.setTitle("Calculation Of Distances");
      myframe.setVisible(true);
   }
   
   /** paintComponent paints the panel
     * @param g - the ``graphics pen'' that draws the items */
   public void paintComponent(Graphics g)
   {
      g.setColor(Color.black); //set the color of the "pen"
      g.drawString(sentence0, xposition, yposition); // draws a sencente with xposition and yposition coordinates
      g.drawString(sentence1, xposition, yposition + increment);
      g.drawString(sentence2, xposition, yposition + (2 * increment));
      g.drawString(sentence3, xposition, yposition + (3 * increment));
      g.drawString(sentence4, xposition, yposition + (4 * increment));
      g.drawString(sentence5, xposition, yposition + (5 * increment));
      g.drawString(sentence6, xposition, yposition + (6 * increment));
      g.drawString(sentence7, xposition, yposition + (7 * increment));
      g.drawString(sentence8, xposition, yposition + (8 * increment));
      g.drawString(sentence9, xposition, yposition + (9 * increment));
      g.drawString(sentence10, xposition, yposition + (10 * increment));   
   }
   
   /** print0,1...10 displays a new string in the window and calculates the d-value
     * @param s - the sentence to be displayed 
     * @param a - the value of a to be displayed
     * @param a - the value of V to be displayed 
     * @param a - the value of t to be displayed  */
   public void print0(String s, double a, double V, int t) 
   {  
      d = V*t + a*Math.pow(t, 2)/2; // Math.pow(int a, int b); calculates the power b of a number a
      sentence0 = sentence0 + d;
      this.repaint();
   }
   public void print1(String s, double a, double V, int t) 
   {  
      d = V*t + a*Math.pow(t, 2)/2;  
      sentence1 = sentence1 + d;
      this.repaint();
   } 
   public void print2(String s, double a, double V, int t) 
   {  
      d = V*t + a*Math.pow(t, 2)/2;  
      sentence2 = sentence2 + d;
      this.repaint();
   }
   public void print3(String s, double a, double V, int t) 
   {  
      d = V*t + a*Math.pow(t, 2)/2; 
      sentence3 = sentence3 + d;
      this.repaint();
   } 
   public void print4(String s, double a, double V, int t) 
   {  
      d = V*t + a*Math.pow(t, 2)/2; 
      sentence4 = sentence4 + d;
      this.repaint();
   } 
   public void print5(String s, double a, double V, int t) 
   {  
      d = V*t + a*Math.pow(t, 2)/2;  
      sentence5 = sentence5 + d;
      this.repaint();
   } 
   public void print6(String s, double a, double V, int t) 
   {  
      d = V*t + a*Math.pow(t, 2)/2; 
      sentence6 = sentence6 + d;
      this.repaint();
   } 
   public void print7(String s, double a, double V, int t) 
   {  
      d = V*t + a*Math.pow(t, 2)/2; 
      sentence7 = sentence7 + d;
      this.repaint();
   } 
   public void print8(String s, double a, double V, int t) 
   {  
      d = V*t + a*Math.pow(t, 2)/2;  
      sentence8 = sentence8 + d;
      this.repaint();
   } 
   public void print9(String s, double a, double V, int t) 
   {  
      d = V*t + a*Math.pow(t, 2)/2;  
      sentence9 = sentence9 + d;
      this.repaint();
   } 
   public void print10(String s, double a, double V, int t) 
   {  
      d = V*t + a*Math.pow(t, 2)/2; 
      sentence10 = sentence10 + d;
      this.repaint();
   } 
}