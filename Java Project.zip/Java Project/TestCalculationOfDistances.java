import javax.swing.*;
/** TestDetyra class is a test class of the class Detyra 
  * and here we take the results for the input values that we give*/
public class TestCalculationOfDistances
{ 
   public static void main (String [] args)
   {  
      CalculationOfDistances testi1 = new CalculationOfDistances(300, 300);
      
      String s = JOptionPane.showInputDialog("Ju lutemi jepeni vleren e V-se!");
      double V = new Double(s).intValue(); 
   
    
      s = JOptionPane.showInputDialog("Ju lutemi jepeni vleren e a-se!");
      double a = new Double(s).intValue();
     
      testi1.print0(s, a , V , 0);
      testi1.print1(s, a , V , 1);
      testi1.print2(s, a , V , 2);
      testi1.print3(s, a , V , 3);
      testi1.print4(s, a , V , 4);
      testi1.print5(s, a , V , 5);
      testi1.print6(s, a , V , 6);
      testi1.print7(s, a , V , 7);
      testi1.print8(s, a , V , 8);
      testi1.print9(s, a , V , 9);
      testi1.print10(s, a , V , 10);
      
   }
}